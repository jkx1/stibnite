﻿=== Small Dot Cursor Set ===

By: DukeNukem249

Download: http://www.rw-designer.com/cursor-set/smalldot

Author's decription:

My Small Dot cursor set!
I made this set because I think these huge cursors are just annoying. The Small Dot cusors are small but still visible!!
I had a lot of fun making this set (it's also my first one) and I hope you like it!


==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.